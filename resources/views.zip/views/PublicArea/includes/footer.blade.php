  <div class="container-fluid text-center">
          <footer>
            <div class="container">
               <div class="social__media">
                  <div class="icon_text_social">
                     <div class="icon-social">
                        <a href="#"><img src="/images/facebook.png" alt="Facebook" /></a>
                     </div>
                     <p>Facebook</p>
                  </div>
                  <div class="icon_text_social">
                     <div class="icon-social">
                        <a href="#"><img src="/images/instagram.png" alt="Instagram" /></a>
                     </div>
                     <p>Instagram</p>
                  </div>
                  <div class="icon_text_social">
                     <div class="icon-social">
                        <a href="#"><img src="/images/twitter.png" alt="twitter" /></a>
                     </div>
                     <p>X</p>
                  </div>
                  <div class="icon_text_social">
                     <div class="icon-social">
                        <a href="#"><img src="/images/share.png" alt="share" /></a>
                     </div>
                     <p>Email</p>
                  </div>
               </div>
               <div class="footer_text">
                  <h2>
                  <p>LiveFootballToday the home of football <br> </p>
               </div>
            </div>
         </footer>
      </div>
      <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
      <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>

